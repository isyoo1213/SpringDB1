package springDB.jdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
